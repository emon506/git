<?php
// nav menu dynamic
function halim_setup(){
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails',array('post','sliders','teams','testimonials','blogs'));
   
    load_theme_textdomain('halim',get_template_directory_uri().'/languages');
    
    register_nav_menus(array(
        'primary-menu' => __('primary Menu','halim'),

    ));

}
add_action('after_setup_theme','halim_setup');


function halim_theme(){
    wp_enqueue_style('font-Poppins','//fonts.googleapis.com/css?family=Poppins:300,400,500,600,700',array(),'1.0.0','all');

    wp_enqueue_style('bootstrap', get_template_directory_uri() .'/assets/css//bootstrap.min.css', array(), '1.0.0','all');
    wp_enqueue_style('font-awesome',get_template_directory_uri() . '/assets/css/font-awesome.min.css', array(), '1.0.0','all');
    wp_enqueue_style('magnific-popup', get_template_directory_uri() .'/assets/css/css//magnific-popup.css', array(), '1.0.0','all');
    wp_enqueue_style('owl-carousel',get_template_directory_uri() . '/assets/css/owl.carousel.css', array(), '1.0.0','all');
    wp_enqueue_style('style-css',get_template_directory_uri() . '/assets/css/style.css', array(), '1.0.0','all');
    wp_enqueue_style('responsive',get_template_directory_uri() . '/assets/css/responsive.css', array(), '1.0.0','all');
   
    wp_enqueue_style('style', get_stylesheet_uri());


    //  js file load
    // wp_enqueue_script('jquery', get_template_directory_uri() . '/assets/js/jquery.min.js', array('jquery'), '1.0.0',true);
    wp_enqueue_script('popper', get_template_directory_uri() .'/assets/js/popper.min.js', array('jquery'), '1.0.0',true);
    wp_enqueue_script('bootstrap', get_template_directory_uri() .'/assets/js/bootstrap.min.js', array('jquery'), '1.0.0',true);
    wp_enqueue_script('carousel', get_template_directory_uri() .'/assets/js/owl.carousel.min.js', array('jquery'), '1.0.0',true);
    wp_enqueue_script('magnific', get_template_directory_uri() .'/assets/js/jquery.magnific-popup.min.js', array('jquery'), '1.0.0',true);
    wp_enqueue_script('isotope', get_template_directory_uri() .'/assets/js/isotope.min.js', array('jquery'), '1.0.0',true);
    wp_enqueue_script('imageloaded', get_template_directory_uri() .'/assets/js/imageloaded.min.js', array('jquery'), '1.0.0',true);
    wp_enqueue_script('counterup', get_template_directory_uri() .'/assets/js/jquery.counterup.min.js', array('jquery'), '1.0.0',true);
    wp_enqueue_script('waypoint', get_template_directory_uri() .'/assets/js//waypoint.min.js', array('jquery'), '1.0.0',true);
    wp_enqueue_script('main', get_template_directory_uri() .'/assets/js/main.js', array('jquery'), '1.0.0',true);
   
  

}
add_action('wp_enqueue_scripts','halim_theme');
// custom posts
function halim_custom_posts(){
    // slider custom post
    register_post_type('sliders',array(
        'labels' => array(
            'name' => __('sliders' , 'halim'),
            'singular_name' => __('slider','halim'),
        ),
        'public' => true,
        'show_ui' => true,
        'supports' => array('title','editor','thumbnail','custom-fields'),
        'show_in_reset' => true
      
    ));

    // services custom post
    register_post_type('services',array(
        'labels' => array(
            'name' => __('services' , 'halim'),
            'singular_name' => __('servic','halim'),
        ),
        'public' => true,
        'show_ui' => true,
        'supports' => array('title','editor','custom-fields'),
      
      
    ));

    
    // counter custom post
    register_post_type('counters',array(
        'labels' => array(
            'name' => __('counters' , 'halim'),
            'singular_name' => __('counter','halim'),
        ),
        'public' => true,
        'show_ui' => true,
        'supports' => array('title','custom-fields'),
      
      
    ));
    
      // Team custom post
      register_post_type('Teams',array(
        'labels' => array(
            'name' => __('Teams' , 'halim'),
            'singular_name' => __('Team','halim'),
        ),
        'public' => true,
        'show_ui' => true,
        'supports' => array('title','thumbnail','custom-fields'),
      
      
    ));

    
      //Testimonial custom post
      register_post_type('testimonials',array(
        'labels' => array(
            'name' => __('testimonials' , 'halim'),
            'singular_name' => __('testimonial','halim'),
        ),
        'public' => true,
        'show_ui' => true,
        'supports' => array('title','thumbnail','custom-fields'),
      
      
    ));

    
      //blog custom post
      register_post_type('blogs',array(
        'labels' => array(
            'name' => __('blogs' , 'halim'),
            'singular_name' => __('blog','halim'),
        ),
        'public' => true,
        'show_ui' => true,
        'supports' => array('title','editor','thumbnail'),
      
      
    ));



}
add_action('init','halim_custom_posts');


if( function_exists('acf_add_options_page') ) {
    
    acf_add_options_page(array(
        'page_title'    => 'halim options','halim',
        'menu_title'    => 'halim options','halim',
        'menu_slug'     => 'halim-options',
        'capability'    => 'edit_posts',
        'redirect'      => false
    ));
    
    acf_add_options_sub_page(array(
        'page_title'    => 'Theme Header Settings',
        'menu_title'    => 'Header',
        'parent_slug'   => 'theme-general-settings',
    ));
    
    acf_add_options_sub_page(array(
        'page_title'    => 'Theme Footer Settings',
        'menu_title'    => 'Footer',
        'parent_slug'   => 'theme-general-settings',
    ));
    
}